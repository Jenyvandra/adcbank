<?php /* Template Name: Board of Director */ ?>
<?php
get_header();
?>



<?php
get_footer();